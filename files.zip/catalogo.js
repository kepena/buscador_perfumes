/* ============================================================
   CATÁLOGO ADMINISTRABLE — catalogo.js
   Render del catálogo, ajuste de precios global/individual,
   persistencia en localStorage compartida con el test principal.
   ============================================================ */

(function () {
  "use strict";

  const CLAVE_STORAGE = "perfumesPro_preciosOverride";

  /* ============ PERSISTENCIA DE PRECIOS ============ */
  // Guardamos solo las diferencias respecto al precioUSD original de data.js,
  // como un mapa { id: nuevoPrecio }. index.html también lee esta misma
  // clave antes de calcular el Match, así los ajustes se reflejan en el test.

  function leerOverrides() {
    try {
      const raw = localStorage.getItem(CLAVE_STORAGE);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      console.warn("No se pudo leer el almacenamiento local de precios:", e);
      return {};
    }
  }

  function guardarOverrides(overrides) {
    try {
      localStorage.setItem(CLAVE_STORAGE, JSON.stringify(overrides));
    } catch (e) {
      console.warn("No se pudo guardar el almacenamiento local de precios:", e);
    }
  }

  function precioActual(perfume, overrides) {
    const guardado = overrides[perfume.id];
    return typeof guardado === "number" && !Number.isNaN(guardado)
      ? guardado
      : perfume.precioUSD;
  }

  // Determina la categoría de presupuesto (Económico/Medio/Sin límite) a partir
  // del precio actual, para que el filtro del test siga siendo coherente incluso
  // después de un ajuste global grande.
  function categoriaParaPrecio(precio) {
    if (precio <= RANGOS_PRECIO.Económico.max) return "Económico";
    if (precio <= RANGOS_PRECIO.Medio.max) return "Medio";
    return "Sin límite";
  }

  let overrides = leerOverrides();

  /* ============ REFERENCIAS DOM ============ */
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  const gridCatalogo = $("#grid-catalogo");
  const plantillaFila = $("#plantilla-fila-catalogo");
  const inputPorcentaje = $("#input-porcentaje");
  const selectDireccion = $("#select-direccion");
  const btnAplicarGlobal = $("#btn-aplicar-global");
  const btnResetPrecios = $("#btn-reset-precios");
  const panelNota = $("#panel-nota");
  const inputBuscar = $("#input-buscar");
  const chipsFiltro = $$(".filtro-chip");

  let filtroTipoActual = "Todos";
  let terminoBusqueda = "";

  /* ============ RENDER ============ */

  function formatearPrecio(n) {
    return Math.round(n * 100) / 100;
  }

  function renderizarCatalogo() {
    gridCatalogo.innerHTML = "";

    const filtrados = PERFUMES.filter((p) => {
      const coincideTipo = filtroTipoActual === "Todos" || p.tipo === filtroTipoActual;
      const coincideBusqueda =
        !terminoBusqueda || p.nombre.toLowerCase().includes(terminoBusqueda.toLowerCase());
      return coincideTipo && coincideBusqueda;
    });

    if (filtrados.length === 0) {
      const vacio = document.createElement("p");
      vacio.className = "catalogo-vacio";
      vacio.textContent = "No hay fragancias que coincidan con tu búsqueda.";
      gridCatalogo.appendChild(vacio);
      return;
    }

    filtrados.forEach((perfume) => {
      const nodo = plantillaFila.content.cloneNode(true);
      const fila = nodo.querySelector(".fila-catalogo");
      fila.dataset.id = perfume.id;

      const imgEl = nodo.querySelector('[data-campo="imagen"]');
      imgEl.src = perfume.imagen;
      imgEl.alt = `Frasco de ${perfume.nombre}`;
      imgEl.addEventListener("error", function manejarError() {
        imgEl.removeEventListener("error", manejarError);
        imgEl.src = FALLBACK_IMG;
      });

      nodo.querySelector('[data-campo="tipo"]').textContent = perfume.tipo;
      nodo.querySelector('[data-campo="id"]').textContent = `#${perfume.id}`;
      nodo.querySelector('[data-campo="nombre"]').textContent = perfume.nombre;
      nodo.querySelector('[data-campo="notas"]').textContent = perfume.notas;
      nodo.querySelector('[data-campo="aroma"]').textContent = `${perfume.aromaPrincipal} · ${perfume.subAroma}`;
      nodo.querySelector('[data-campo="momento"]').textContent = perfume.momento;
      nodo.querySelector('[data-campo="clima"]').textContent = perfume.clima;
      nodo.querySelector('[data-campo="potencia"]').textContent = perfume.potencia;

      const precio = precioActual(perfume, overrides);
      const inputPrecio = nodo.querySelector('[data-campo="precio-input"]');
      inputPrecio.value = formatearPrecio(precio);
      inputPrecio.dataset.id = perfume.id;

      const spanOriginal = nodo.querySelector('[data-campo="precio-original"]');
      const spanCategoria = nodo.querySelector('[data-campo="presupuesto"]');
      actualizarEtiquetasPrecio(spanOriginal, spanCategoria, perfume, precio);

      inputPrecio.addEventListener("change", () => {
        const nuevoValor = parseFloat(inputPrecio.value);
        if (Number.isNaN(nuevoValor) || nuevoValor <= 0) {
          inputPrecio.value = formatearPrecio(precioActual(perfume, overrides));
          return;
        }
        guardarPrecioIndividual(perfume.id, nuevoValor);
        const precioNuevo = precioActual(perfume, overrides);
        actualizarEtiquetasPrecio(spanOriginal, spanCategoria, perfume, precioNuevo);
      });

      gridCatalogo.appendChild(nodo);
    });
  }

  function actualizarEtiquetasPrecio(spanOriginal, spanCategoria, perfume, precioMostrado) {
    const original = perfume.precioUSD;
    if (formatearPrecio(precioMostrado) !== formatearPrecio(original)) {
      spanOriginal.textContent = `Original: $${formatearPrecio(original)}`;
      spanOriginal.classList.add("cambiado");
    } else {
      spanOriginal.textContent = "Precio original";
      spanOriginal.classList.remove("cambiado");
    }
    spanCategoria.textContent = categoriaParaPrecio(precioMostrado);
  }

  /* ============ AJUSTE GLOBAL POR PORCENTAJE ============ */

  function guardarPrecioIndividual(id, nuevoPrecio) {
    overrides[id] = formatearPrecio(nuevoPrecio);
    guardarOverrides(overrides);
  }

  function aplicarAjusteGlobal() {
    const porcentaje = parseFloat(inputPorcentaje.value);
    if (Number.isNaN(porcentaje) || porcentaje < 0) {
      panelNota.textContent = "Ingresa un porcentaje válido (0 o mayor).";
      return;
    }
    const direccion = selectDireccion.value; // "subir" | "bajar"
    const factor = direccion === "subir" ? 1 + porcentaje / 100 : 1 - porcentaje / 100;

    PERFUMES.forEach((perfume) => {
      const base = precioActual(perfume, overrides);
      const nuevo = Math.max(1, formatearPrecio(base * factor));
      overrides[perfume.id] = nuevo;
    });

    guardarOverrides(overrides);
    renderizarCatalogo();

    const verbo = direccion === "subir" ? "subido" : "bajado";
    panelNota.textContent = `Precios de las 50 fragancias ${verbo} un ${porcentaje}%. Los cambios ya se aplican también en los resultados del test.`;
  }

  function restablecerPrecios() {
    overrides = {};
    guardarOverrides(overrides);
    renderizarCatalogo();
    panelNota.textContent = "Precios restablecidos a los valores originales del catálogo.";
  }

  /* ============ FILTROS Y BÚSQUEDA ============ */

  function seleccionarFiltroTipo(tipo) {
    filtroTipoActual = tipo;
    chipsFiltro.forEach((chip) => {
      chip.classList.toggle("activo", chip.dataset.filtroTipo === tipo);
    });
    renderizarCatalogo();
  }

  /* ============ EVENT LISTENERS ============ */

  btnAplicarGlobal.addEventListener("click", aplicarAjusteGlobal);
  btnResetPrecios.addEventListener("click", restablecerPrecios);

  chipsFiltro.forEach((chip) => {
    chip.addEventListener("click", () => seleccionarFiltroTipo(chip.dataset.filtroTipo));
  });

  let debounceBusqueda = null;
  inputBuscar.addEventListener("input", () => {
    clearTimeout(debounceBusqueda);
    debounceBusqueda = setTimeout(() => {
      terminoBusqueda = inputBuscar.value.trim();
      renderizarCatalogo();
    }, 150);
  });

  /* ============ INICIO ============ */
  renderizarCatalogo();
})();
