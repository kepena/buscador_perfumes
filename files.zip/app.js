/* ============================================================
   BUSCADOR DE PERFUMES PRO — app.js
   Navegación, ramificación dinámica y motor de Match %
   ============================================================ */

(function () {
  "use strict";

  /* ============ DEFINICIÓN DEL FLUJO DE PREGUNTAS ============ */
  // Cada pregunta tiene una "clave" (campo de respuesta) y opciones.
  // La pregunta 2 tiene subpreguntas condicionadas por su respuesta.

  const PREGUNTA_1 = {
    clave: "tipo",
    numero: "1 de 7",
    titulo: "¿Para quién o qué estilo buscas?",
    opciones: [
      { valor: "Cualquiera", emoji: "🎲", titulo: "Me da igual la marca", desc: "Solo quiero oler brutal" },
      { valor: "Diseñador", emoji: "👑", titulo: "De marca famosa / Diseñador", desc: "Versace, Dior, CH" },
      { valor: "Árabe", emoji: "🕌", titulo: "Árabes", desc: "Duraderos y económicos: Lattafa, Armaf, Afnan" },
      { valor: "Lujo", emoji: "💎", titulo: "Lujo / Exclusivos", desc: "Caros, raros y de altísima calidad" }
    ]
  };

  const PREGUNTA_2 = {
    clave: "aromaPrincipal",
    numero: "2 de 7",
    titulo: "¿A qué quieres oler principalmente?",
    opciones: [
      { valor: "Fresco", emoji: "🌊", titulo: "Fresco o a limpio", desc: "" },
      { valor: "Dulce", emoji: "🍦", titulo: "Dulce o \u201Ccomestible\u201D", desc: "" },
      { valor: "Madera", emoji: "🌲", titulo: "A madera o elegante", desc: "" }
    ]
  };

  // Subpreguntas 2.5 — la clave siempre es "subAroma"
  const SUBPREGUNTAS = {
    Fresco: {
      numero: "2.5 de 7",
      titulo: "Perfecto, un poco más de detalle sobre ese frescor \u2192",
      opciones: [
        { valor: "Cítricos variados", emoji: "🍋", titulo: "A cítricos", desc: "Limón, mandarina, naranja" },
        { valor: "Playa / mar", emoji: "🏖️", titulo: "A playa / mar", desc: "Brisa marina, aire puro, agua" },
        { valor: "A recién bañado", emoji: "🧼", titulo: "A recién bañado", desc: "Limpio, suave, jabón" },
        { valor: "Plantas / menta", emoji: "🌿", titulo: "A plantas / menta", desc: "Hierba fresca, menta, té" }
      ]
    },
    Dulce: {
      numero: "2.5 de 7",
      titulo: "Perfecto, un poco más de detalle sobre ese dulzor \u2192",
      opciones: [
        { valor: "Postre / Vainilla", emoji: "🍨", titulo: "Postre / Vainilla", desc: "Vainilla, caramelo, chocolate" },
        { valor: "Frutas jugosas", emoji: "🍏", titulo: "Frutas jugosas", desc: "Manzana, piña, mango, sandía" },
        { valor: "Cálido e intenso", emoji: "🍯", titulo: "Cálido e intenso", desc: "Miel, canela, especias" }
      ]
    },
    Madera: {
      numero: "2.5 de 7",
      titulo: "Perfecto, un poco más de detalle sobre esa madera \u2192",
      opciones: [
        { valor: "Madera suave", emoji: "🪵", titulo: "Madera suave", desc: "Bosque, lápiz de madera, elegante" },
        { valor: "Misterioso", emoji: "💨", titulo: "Misterioso", desc: "Toque a humo, cuero o tabaco" },
        { valor: "Árabe potente", emoji: "🕌", titulo: "Árabe potente", desc: "Exótica / Oud fuerte" }
      ]
    }
  };

  const PREGUNTA_3 = {
    clave: "momento",
    numero: "3 de 7",
    titulo: "¿En qué momento lo vas a usar más?",
    opciones: [
      { valor: "Diario", emoji: "☀️", titulo: "Todos los días / Colegio / Trabajo", desc: "Que no maree" },
      { valor: "Citas", emoji: "🌙", titulo: "Para salir de noche / Citas", desc: "Para gustarle a alguien" },
      { valor: "Fiesta", emoji: "🕺", titulo: "Fiesta / Discoteca", desc: "Para proyectar a metros" },
      { valor: "Deporte", emoji: "🏋️", titulo: "Deporte / Días de mucho calor", desc: "Súper fresco" }
    ]
  };

  const PREGUNTA_4 = {
    clave: "clima",
    numero: "4 de 7",
    titulo: "¿Cómo es el clima donde vives o donde lo vas a usar?",
    opciones: [
      { valor: "Frío / Noche", emoji: "❄️", titulo: "Frío / De noche", desc: "Soporta aromas dulces y pesados" },
      { valor: "Caliente / Sol", emoji: "☀️", titulo: "Caliente / Soleado", desc: "Súper fresco" },
      { valor: "Templado", emoji: "⛅", titulo: "Templado / De todo un poco", desc: "Todo el año" }
    ]
  };

  const PREGUNTA_5 = {
    clave: "estilo",
    numero: "5 de 7",
    titulo: "¿Qué edad tienes o qué estilo buscas transmitir?",
    opciones: [
      { valor: "Joven", emoji: "🧢", titulo: "Joven / Juvenil", desc: "Divertido, moderno, llamativo" },
      { valor: "Formal", emoji: "👔", titulo: "Maduro / Formal", desc: "Serio, elegante, de presencia" },
      { valor: "Versátil", emoji: "⚡", titulo: "Sin edad / Versátil", desc: "Le queda bien a cualquiera" }
    ]
  };

  const PREGUNTA_6 = {
    clave: "potencia",
    numero: "6 de 7",
    titulo: "¿Cuánto quieres que dure y se sienta?",
    opciones: [
      { valor: "Modo Bestia", emoji: "💥", titulo: "Modo Bestia", desc: "Deja huella gigante y dura +12h" },
      { valor: "Normal", emoji: "⚖️", titulo: "Normal / Equilibrado", desc: "1 a 2 metros sin marear" },
      { valor: "Suave", emoji: "🤫", titulo: "Suave", desc: "Solo al abrazar" }
    ]
  };

  const PREGUNTA_7 = {
    clave: "presupuesto",
    numero: "7 de 7",
    titulo: "¿Cuánto dinero quieres gastar aprox?",
    opciones: [
      { valor: "Económico", emoji: "🟢", titulo: "Económico", desc: "Bueno y barato" },
      { valor: "Medio", emoji: "🟡", titulo: "Término medio", desc: "Precio estándar de tienda" },
      { valor: "Sin límite", emoji: "🔴", titulo: "Sin problema de presupuesto", desc: "Lo mejor" }
    ]
  };

  /* ============ ESTADO GLOBAL DE LA APP ============ */
  // El "camino" (path) de pasos se construye dinámicamente porque el paso 2.5
  // depende de la respuesta de la pregunta 2.
  const estado = {
    pasoActual: 0,          // índice dentro de `camino`
    camino: [PREGUNTA_1, PREGUNTA_2], // se completa dinámicamente
    respuestas: {}          // { tipo, aromaPrincipal, subAroma, momento, clima, estilo, potencia, presupuesto }
  };

  /* ============ PRECIOS AJUSTADOS DESDE EL CATÁLOGO ============ */
  // El catálogo (catalogo.html) permite subir/bajar precios global o
  // individualmente y los guarda en localStorage. Aquí los leemos para
  // que el test use siempre el precio vigente, no el original de data.js.
  const CLAVE_STORAGE_PRECIOS = "perfumesPro_preciosOverride";

  function leerOverridesPrecio() {
    try {
      const raw = localStorage.getItem(CLAVE_STORAGE_PRECIOS);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function precioVigente(perfume, overrides) {
    const guardado = overrides[perfume.id];
    return typeof guardado === "number" && !Number.isNaN(guardado)
      ? guardado
      : perfume.precioUSD;
  }

  function categoriaParaPrecio(precio) {
    if (precio <= RANGOS_PRECIO.Económico.max) return "Económico";
    if (precio <= RANGOS_PRECIO.Medio.max) return "Medio";
    return "Sin límite";
  }

  /* ============ REFERENCIAS DOM ============ */
  const $ = (sel) => document.querySelector(sel);

  const pantallaInicio = $("#pantalla-inicio");
  const pantallaTest = $("#pantalla-test");
  const pantallaResultados = $("#pantalla-resultados");

  const btnEmpezar = $("#btn-empezar");
  const btnAtras = $("#btn-atras");
  const btnSiguiente = $("#btn-siguiente");
  const btnReiniciar = $("#btn-reiniciar");

  const preguntaContenedor = $("#pregunta-contenedor");
  const progresoTexto = $("#progreso-texto");
  const progresoPorcentaje = $("#progreso-porcentaje");
  const progresoRelleno = $("#progreso-relleno");
  const tarjetasResultado = $("#tarjetas-resultado");
  const plantillaTarjeta = $("#plantilla-tarjeta");

  const TOTAL_PASOS_VISUALES = 7; // para el indicador "Paso X de 7", aunque el camino real tenga 8 nodos (2.5)

  let avanceAutomaticoTimeout = null; // controla el avance automático tras seleccionar una opción

  /* ============ NAVEGACIÓN ============ */

  function irAPantalla(pantalla) {
    [pantallaInicio, pantallaTest, pantallaResultados].forEach((p) =>
      p.classList.remove("activa")
    );
    pantalla.classList.add("activa");
    // El contenido de la pantalla (preguntas o tarjetas) ya debe estar
    // renderizado ANTES de llamar a esta función, para que el navegador
    // calcule el scroll sobre el layout final y no salte después.
    setTimeout(() => {
      pantalla.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 0);
  }

  function iniciarTest() {
    estado.pasoActual = 0;
    estado.camino = [PREGUNTA_1, PREGUNTA_2];
    estado.respuestas = {};
    renderizarPregunta();
    irAPantalla(pantallaTest);
  }

  function construirCaminoTrasPregunta2() {
    // Inserta la subpregunta correspondiente justo después de la pregunta 2
    const aroma = estado.respuestas.aromaPrincipal;
    const sub = SUBPREGUNTAS[aroma];
    const subPregunta = {
      clave: "subAroma",
      numero: sub.numero,
      titulo: sub.titulo,
      opciones: sub.opciones
    };
    // camino: [P1, P2, SUB, P3, P4, P5, P6, P7]
    estado.camino = [
      PREGUNTA_1,
      PREGUNTA_2,
      subPregunta,
      PREGUNTA_3,
      PREGUNTA_4,
      PREGUNTA_5,
      PREGUNTA_6,
      PREGUNTA_7
    ];
  }

  function renderizarPregunta() {
    const pregunta = estado.camino[estado.pasoActual];
    const respuestaActual = estado.respuestas[pregunta.clave];

    // Indicador de progreso: mapeamos el paso real a un "paso visual" de 7
    const pasoVisual = calcularPasoVisual();
    progresoTexto.textContent = `Paso ${pasoVisual} de ${TOTAL_PASOS_VISUALES}`;
    const pct = Math.round((pasoVisual / TOTAL_PASOS_VISUALES) * 100);
    progresoPorcentaje.textContent = `${pct}%`;
    progresoRelleno.style.width = `${pct}%`;

    // Render de la pregunta
    preguntaContenedor.innerHTML = "";

    const numeroEl = document.createElement("p");
    numeroEl.className = "pregunta-numero";
    numeroEl.textContent = `Pregunta ${pregunta.numero}`;

    const tituloEl = document.createElement("h2");
    tituloEl.className = "pregunta-titulo";
    tituloEl.textContent = pregunta.titulo;

    const gridEl = document.createElement("div");
    gridEl.className = "opciones-grid";
    gridEl.setAttribute("role", "radiogroup");
    gridEl.setAttribute("aria-label", pregunta.titulo);

    pregunta.opciones.forEach((opcion) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "opcion";
      btn.setAttribute("role", "radio");
      btn.setAttribute("aria-checked", opcion.valor === respuestaActual ? "true" : "false");
      if (opcion.valor === respuestaActual) btn.classList.add("seleccionada");

      const emojiEl = document.createElement("span");
      emojiEl.className = "opcion-emoji";
      emojiEl.textContent = opcion.emoji;
      emojiEl.setAttribute("aria-hidden", "true");

      const textoWrap = document.createElement("span");
      textoWrap.className = "opcion-texto";

      const tituloOpcion = document.createElement("span");
      tituloOpcion.className = "opcion-titulo";
      tituloOpcion.textContent = opcion.titulo;
      textoWrap.appendChild(tituloOpcion);

      if (opcion.desc) {
        const descOpcion = document.createElement("span");
        descOpcion.className = "opcion-desc";
        descOpcion.textContent = opcion.desc;
        textoWrap.appendChild(descOpcion);
      }

      btn.appendChild(emojiEl);
      btn.appendChild(textoWrap);

      btn.addEventListener("click", () => seleccionarOpcion(pregunta.clave, opcion.valor));

      gridEl.appendChild(btn);
    });

    preguntaContenedor.appendChild(numeroEl);
    preguntaContenedor.appendChild(tituloEl);
    preguntaContenedor.appendChild(gridEl);

    actualizarBotonesNav();
  }

  function calcularPasoVisual() {
    // Pasos 0,1 -> visual 1,2. Si estamos en la subpregunta (índice 2 cuando existe), sigue siendo "2".
    // A partir de ahí, el índice real se corre +1 respecto al visual (por el nodo de subpregunta).
    const idx = estado.pasoActual;
    if (idx <= 1) return idx + 1; // preguntas 1 y 2
    if (estado.camino.length === 8) {
      if (idx === 2) return 2; // subpregunta 2.5 sigue mostrando "2"
      return idx; // idx=3->3, 4->4, 5->5, 6->6, 7->7
    }
    return idx + 1;
  }

  function seleccionarOpcion(clave, valor) {
    estado.respuestas[clave] = valor;

    // Si acabamos de responder la pregunta 2, construir el camino con la subpregunta correcta
    if (clave === "aromaPrincipal") {
      construirCaminoTrasPregunta2();
    }

    renderizarPregunta();

    // Avance automático: dejamos un instante para que se vea la opción
    // resaltada como seleccionada, y luego pasamos solos al siguiente paso
    // (o a resultados si era la última pregunta).
    clearTimeout(avanceAutomaticoTimeout);
    avanceAutomaticoTimeout = setTimeout(() => {
      irSiguiente();
    }, 380);
  }

  function actualizarBotonesNav() {
    const pregunta = estado.camino[estado.pasoActual];
    const respondida = Boolean(estado.respuestas[pregunta.clave]);
    btnSiguiente.disabled = !respondida;
    btnAtras.disabled = estado.pasoActual === 0;

    const esUltimoPaso = estado.pasoActual === estado.camino.length - 1;
    btnSiguiente.innerHTML = esUltimoPaso
      ? "Ver mis resultados <span class='flecha'>✦</span>"
      : "Siguiente <span class='flecha'>→</span>";
  }

  function irSiguiente() {
    clearTimeout(avanceAutomaticoTimeout);
    const esUltimoPaso = estado.pasoActual === estado.camino.length - 1;
    if (esUltimoPaso) {
      mostrarResultados();
      return;
    }
    estado.pasoActual += 1;
    renderizarPregunta();
  }

  function irAtras() {
    clearTimeout(avanceAutomaticoTimeout);
    if (estado.pasoActual === 0) return;
    estado.pasoActual -= 1;
    renderizarPregunta();
  }

  /* ============ MOTOR DE RECOMENDACIÓN (MATCH %) ============ */

  // El presupuesto elegido en la pregunta 7 define cuánto está dispuesto a
  // pagar el usuario COMO MÁXIMO. "Económico" solo debe mostrar perfumes
  // económicos; "Medio" acepta económico + medio (no obliga a gastar más
  // de lo pedido); "Sin límite" acepta cualquier precio. Así el presupuesto
  // actúa como FILTRO real, no solo como un bonus de puntos que un perfume
  // caro podía compensar con otras coincidencias.
  //
  // La categoría de precio se recalcula a partir del precio VIGENTE (con
  // los ajustes hechos en el catálogo), no del precioUSD original de
  // data.js, para que subir o bajar precios en el catálogo cambie de
  // verdad qué perfumes caben en cada presupuesto.
  const ORDEN_PRESUPUESTO = ["Económico", "Medio", "Sin límite"];

  function presupuestoCompatible(categoriaPerfume, presupuestoElegido) {
    const techoUsuario = ORDEN_PRESUPUESTO.indexOf(presupuestoElegido);
    const nivelPerfume = ORDEN_PRESUPUESTO.indexOf(categoriaPerfume);
    // El perfume es compatible si su nivel de precio no supera el techo elegido.
    return nivelPerfume <= techoUsuario;
  }

  function calcularScore(perfume, categoriaPerfume, r) {
    let score = 0;

    // Aroma Principal: +25
    if (perfume.aromaPrincipal === r.aromaPrincipal) score += 25;

    // Sub-aroma: +15
    if (perfume.subAroma === r.subAroma) score += 15;

    // Tipo/Marca: +15 (o si eligió "Cualquiera")
    if (r.tipo === "Cualquiera" || perfume.tipo === r.tipo) score += 15;

    // Momento: +15
    if (perfume.momento === r.momento) score += 15;

    // Clima: +15
    if (perfume.clima === r.clima) score += 15;

    // Estilo/Edad: +5
    if (perfume.estilo === r.estilo) score += 5;

    // Potencia: +5
    if (perfume.potencia === r.potencia) score += 5;

    // Presupuesto exacto: +5 extra (además del filtro, premiamos el match perfecto de precio)
    if (categoriaPerfume === r.presupuesto) score += 5;

    return score; // máximo teórico: 100
  }

  function obtenerTop4() {
    const r = estado.respuestas;
    const overrides = leerOverridesPrecio();

    // 1. Calculamos el precio vigente y la categoría de cada perfume, y
    //    filtramos por presupuesto usando esa categoría dinámica.
    const conPrecioVigente = PERFUMES.map((p) => {
      const precio = precioVigente(p, overrides);
      return { perfume: p, precio, categoria: categoriaParaPrecio(precio) };
    });

    const dentroDePresupuesto = conPrecioVigente.filter((item) =>
      presupuestoCompatible(item.categoria, r.presupuesto)
    );

    // 2. Puntuamos solo dentro de ese subconjunto ya filtrado.
    const puntuados = dentroDePresupuesto.map((item) => ({
      ...item,
      score: calcularScore(item.perfume, item.categoria, r)
    }));

    puntuados.sort((a, b) => b.score - a.score);

    // 3. Tomamos los 4 mejores DENTRO del presupuesto vigente.
    const top4 = puntuados.slice(0, 4);

    // El % de Match mostrado es el score REAL calculado arriba, sin piso
    // artificial. El precio mostrado es el vigente (con ajustes del
    // catálogo aplicados), no el original de data.js.
    return top4.map((item) => ({
      ...item.perfume,
      precioUSD: item.precio,
      matchPct: Math.min(100, item.score)
    }));
  }

  /* ============ RENDER DE RESULTADOS ============ */

  function mostrarResultados() {
    const top4 = obtenerTop4();

    tarjetasResultado.innerHTML = "";

    top4.forEach((perfume) => {
      const nodo = plantillaTarjeta.content.cloneNode(true);

      const imgEl = nodo.querySelector('[data-campo="imagen"]');
      imgEl.src = perfume.imagen;
      imgEl.alt = `Frasco de ${perfume.nombre}`;
      imgEl.addEventListener("error", function manejarError() {
        imgEl.removeEventListener("error", manejarError);
        imgEl.src = FALLBACK_IMG;
      });

      nodo.querySelector('[data-campo="match"]').textContent = `${perfume.matchPct}% Match`;
      nodo.querySelector('[data-campo="tipo"]').textContent = perfume.tipo;
      nodo.querySelector('[data-campo="precio"]').textContent = `$${perfume.precioUSD}`;
      nodo.querySelector('[data-campo="nombre"]').textContent = perfume.nombre;
      nodo.querySelector('[data-campo="aroma"]').textContent = `${perfume.aromaPrincipal} · ${perfume.subAroma}`;
      nodo.querySelector('[data-campo="momento"]').textContent = `Ideal para ${perfume.momento.toLowerCase()}`;
      nodo.querySelector('[data-campo="notas"]').textContent = perfume.notas;

      tarjetasResultado.appendChild(nodo);
    });

    irAPantalla(pantallaResultados);
  }

  /* ============ EVENT LISTENERS GLOBALES ============ */

  btnEmpezar.addEventListener("click", iniciarTest);
  btnSiguiente.addEventListener("click", irSiguiente);
  btnAtras.addEventListener("click", irAtras);
  btnReiniciar.addEventListener("click", iniciarTest);

  // Al cargar, aseguramos que la pantalla de inicio esté activa
  irAPantalla(pantallaInicio);
})();
